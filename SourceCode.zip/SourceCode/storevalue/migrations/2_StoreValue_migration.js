// 2_StoreValue_migration.js

var Migrations = artifacts.require("StoreValue");

module.exports = function (deployer) {
  deployer.deploy(Migrations);
};